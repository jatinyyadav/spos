#include <stdio.h>
#include <dlfcn.h>

int main() {
    void *handle;
    int (*add_func)(int, int);
    char *error;

    handle = dlopen("./libmathlib.so", RTLD_LAZY);
    if (!handle) {
        fprintf(stderr, "%s\n", dlerror());
        return 1;
    }

    add_func = dlsym(handle, "add");
    if ((error = dlerror()) != NULL) {
        fprintf(stderr, "%s\n", error);
        return 1;
    }

    printf("Result: %d\n", add_func(10, 5));

    dlclose(handle);
    return 0;
}
