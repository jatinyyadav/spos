#include <stdio.h>
#include <math.h>
#include <string.h>

// Arithmetic operations
double add(double a, double b) { return a + b; }
double sub(double a, double b) { return a - b; }
double mul(double a, double b) { return a * b; }
double divide(double a, double b) { return (b != 0) ? a / b : 0; }

// Trigonometric operations
double sine(double x) { return sin(x); }
double cosine(double x) { return cos(x); }

// String operation
void concat(char *s1, char *s2, char *result) {
    strcpy(result, s1);
    strcat(result, s2);
}
