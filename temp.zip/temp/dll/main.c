#include <stdio.h>
#include <dlfcn.h>

int main() {
    void *handle;
    double (*add)(double, double);
    double (*sine)(double);
    void (*concat)(char*, char*, char*);
    char *error;

    // Load the shared library
    handle = dlopen("./libmathlib.so", RTLD_LAZY);
    if (!handle) {
        fprintf(stderr, "%s\n", dlerror());
        return 1;
    }

    // Clear existing errors
    dlerror();

    // Get symbols (function pointers)
    add = dlsym(handle, "add");
    sine = dlsym(handle, "sine");
    concat = dlsym(handle, "concat");

    // Check for errors
    if ((error = dlerror()) != NULL) {
        fprintf(stderr, "%s\n", error);
        return 1;
    }

    // Use the functions
    printf("Add(5, 3) = %.2f\n", (*add)(5, 3));
    printf("Sine(0.5) = %.2f\n", (*sine)(0.5));

    char s1[20] = "Hello, ";
    char s2[20] = "World!";
    char result[50];
    (*concat)(s1, s2, result);
    printf("Concat result = %s\n", result);

    // Close library
    dlclose(handle);
    return 0;
}
