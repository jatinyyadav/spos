import java.util.*;

/**
 * Simple symbol table implementation.  Stores a mapping from symbol
 * names to their addresses.  Symbols are recorded in the order
 * encountered to preserve indices used in the intermediate code.  A
 * forward reference (symbol encountered before its definition) has
 * address -1 until it is later updated with {@link #updateAddress}.
 */
public class SymbolTable {
    private final Map<String, Integer> symbolMap = new LinkedHashMap<>();
    private final List<String> symbolList = new ArrayList<>();

    /** Add a symbol to the table with the given address.  If the symbol
     * already exists, its address is left unchanged; use
     * {@link #updateAddress(String, int)} to update it. */
    public void addSymbol(String symbol, int address) {
        if (!symbolMap.containsKey(symbol)) {
            symbolMap.put(symbol, address);
            symbolList.add(symbol);
        }
    }

    /** Returns true if the symbol is present in the table. */
    public boolean isSymbol(String symbol) {
        return symbolMap.containsKey(symbol);
    }

    /** Returns the index of the symbol in the symbol list, or -1 if not found. */
    public int getSymbolIndex(String symbol) {
        return symbolList.indexOf(symbol);
    }

    /** Returns the address of the symbol at the given index.  If the symbol
     * does not have an address defined (e.g. forward reference), -1 is
     * returned. */
    public int getAddressByIndex(int idx) {
        if (idx >= 0 && idx < symbolList.size()) {
            String sym = symbolList.get(idx);
            return symbolMap.getOrDefault(sym, -1);
        }
        return -1;
    }

    /** Returns the address associated with the given symbol, or -1 if unknown. */
    public int getAddress(String symbol) {
        return symbolMap.getOrDefault(symbol, -1);
    }

    /** Updates the address of an existing symbol.  If the symbol is not
     * present it will be added. */
    public void updateAddress(String symbol, int address) {
        symbolMap.put(symbol, address);
        if (!symbolList.contains(symbol)) {
            symbolList.add(symbol);
        }
    }
}