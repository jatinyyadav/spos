import java.io.*;
import java.util.*;

/**
 * Main assembler class that performs a two‑pass assembly.  This version
 * separates the symbol, literal and opcode tables into distinct
 * classes for clarity.  The assembler reads an assembly source
 * program from {@code input.txt}, writes an intermediate representation
 * to {@code intermediate.txt} and generates the final machine code
 * listing in {@code machinecode.txt}.  The intermediate and final
 * listings include the original assembly line to ease tracing.
 */
public class Pass2 {

    public static void main(String[] args) throws IOException {
        String inputFile = "input.txt";
        String intermediateFile = "intermediate.txt";
        String machineCodeFile = "machinecode.txt";

        SymbolTable symtab = new SymbolTable();
        LiteralTable littab = new LiteralTable();
        OpcodeTable optab = new OpcodeTable();
        List<String> intermLines = new ArrayList<>();
        List<String> machineLines = new ArrayList<>();

        // Pass 1: Read the source, build tables and generate intermediate code
        int lc = 0;
        boolean startFound = false;
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                // Remove commas to simplify tokenisation
                String[] tokens = line.replace(",", "").split("\\s+");
                if (tokens.length == 0) continue;
                String asmLine = String.join(" ", tokens);

                if (tokens[0].equals("START")) {
                    // START directive sets the initial LC
                    if (tokens.length < 2) {
                        throw new IllegalArgumentException("START directive requires an address");
                    }
                    lc = Integer.parseInt(tokens[1]);
                    startFound = true;
                    intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", asmLine, lc, "AD", "1", "C,"+tokens[1], "-"));
                    continue;
                }
                if (!startFound) {
                    throw new IllegalStateException("Source program missing START before instructions: " + asmLine);
                }
                String mnemonic = tokens[0];
                if (optab.isOpcode(mnemonic)) {
                    // Imperative statement: determine opcode and operands
                    String instrClass = "IS";
                    int opcodeNum = optab.getOpcode(mnemonic);
                    String op1Str = "-";
                    String op2Str = "-";
                    // Operand1 (usually a register or symbol)
                    if (tokens.length > 1) {
                        String op1Tok = tokens[1];
                        int reg1 = optab.getRegister(op1Tok);
                        if (reg1 > 0) {
                            op1Str = String.valueOf(reg1);
                        } else {
                            // If operand1 is numeric constant treat as constant
                            try {
                                Integer.parseInt(op1Tok);
                                op1Str = "C," + op1Tok;
                            } catch (NumberFormatException ex) {
                                // Treat as symbol
                                if (!symtab.isSymbol(op1Tok)) {
                                    symtab.addSymbol(op1Tok, -1);
                                }
                                op1Str = "S," + symtab.getSymbolIndex(op1Tok);
                            }
                        }
                    }
                    // Operand2 (register, symbol, literal or constant)
                    if (tokens.length > 2) {
                        String op2Tok = tokens[2];
                        if (op2Tok.startsWith("=")) {
                            littab.addLiteral(op2Tok);
                            op2Str = "L," + littab.getLiteralIndex(op2Tok);
                        } else {
                            int reg2 = optab.getRegister(op2Tok);
                            if (reg2 > 0) {
                                op2Str = String.valueOf(reg2);
                            } else {
                                // numeric constant?
                                try {
                                    Integer.parseInt(op2Tok);
                                    op2Str = "C," + op2Tok;
                                } catch (NumberFormatException ex) {
                                    // symbol
                                    if (!symtab.isSymbol(op2Tok)) {
                                        symtab.addSymbol(op2Tok, -1);
                                    }
                                    op2Str = "S," + symtab.getSymbolIndex(op2Tok);
                                }
                            }
                        }
                    }
                    intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", asmLine, lc, instrClass, opcodeNum, op1Str, op2Str));
                    lc++;
                } else if (mnemonic.equals("DC")) {
                    // DC without label
                    if (tokens.length < 2) {
                        throw new IllegalArgumentException("DC requires a constant value");
                    }
                    String value = tokens[1];
                    intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", asmLine, lc, "DL", "1", "C,"+value, "-"));
                    lc++;
                } else if (mnemonic.equals("END")) {
                    // END directive: allocate any outstanding literals
                    intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", asmLine, lc, "AD", "2", "-", "-"));
                    // Assign addresses to literals and emit a DL line for each
                    littab.assignAddresses(lc);
                    for (LiteralTable.LiteralEntry lit : littab.literals) {
                        if (lit.address >= lc) {
                            // Use the literal value without '=' when printing
                            String litVal = lit.value.substring(1);
                            intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", "(literal)", lit.address, "DL", "1", "C,"+litVal, "-"));
                            lc++;
                        }
                    }
                    break;
                } else if (tokens.length >= 3 && tokens[1].equals("DC")) {
                    // Labelled DC directive: <label> DC <value>
                    String label = tokens[0];
                    String value = tokens[2];
                    if (!symtab.isSymbol(label)) {
                        symtab.addSymbol(label, lc);
                    } else {
                        // update address if forward reference
                        symtab.updateAddress(label, lc);
                    }
                    intermLines.add(String.format("%-25s %3s %-7s %-7s %-10s %-10s", asmLine, lc, "DL", "1", "C,"+value, "-"));
                    lc++;
                } else {
                    throw new IllegalArgumentException("Unknown statement: " + asmLine);
                }
            }
        }
        // Write intermediate file with header
        try (PrintWriter pw = new PrintWriter(new FileWriter(intermediateFile))) {
            pw.println(String.format("%-25s %-3s %-7s %-7s %-10s %-10s", "Input", "LC", "Class", "Opcode", "Operand1", "Operand2"));
            for (String s : intermLines) {
                pw.println(s);
            }
        }

        // Pass 2: Generate machine code from intermediate representation
        for (String line : intermLines) {
            // Skip header lines (if any).  The intermediate lines always begin with the original assembly or "(literal)".
            if (line.trim().isEmpty()) continue;
            String asmLine = line.substring(0, 25).trim();
            // Parse the remainder of the line after the first 25 characters into columns
            String rest = line.length() > 25 ? line.substring(25).trim() : "";
            if (rest.isEmpty()) continue;
            String[] cols = rest.split("\\s+");
            // We expect: LC, Class, Opcode, Operand1, Operand2
            if (cols.length < 3) continue;
            String lcStr = cols[0];
            String cls = cols[1];
            String opcodeStr = cols[2];
            String op1 = cols.length > 3 ? cols[3] : "-";
            String op2 = cols.length > 4 ? cols[4] : "-";
            // Convert LC from string to integer
            int loc = 0;
            try {
                loc = Integer.parseInt(lcStr);
            } catch (NumberFormatException ex) {
                continue;
            }
            if (cls.equals("IS")) {
                int opcodeNum = 0;
                try {
                    opcodeNum = Integer.parseInt(opcodeStr);
                } catch (NumberFormatException ex) {
                    opcodeNum = 0;
                }
                int regNum = 0;
                int addrVal = 0;
                // Resolve first operand (register, symbol or constant)
                if (!op1.equals("-")) {
                    if (op1.startsWith("S,")) {
                        int idx = Integer.parseInt(op1.substring(2));
                        addrVal = symtab.getAddressByIndex(idx);
                    } else if (op1.startsWith("L,")) {
                        int idx = Integer.parseInt(op1.substring(2));
                        addrVal = littab.literals.get(idx).address;
                    } else if (op1.startsWith("C,")) {
                        addrVal = Integer.parseInt(op1.substring(2));
                    } else {
                        // numeric register code
                        try {
                            regNum = Integer.parseInt(op1);
                        } catch (NumberFormatException ex) {
                            // treat as symbol index string? not expected
                        }
                    }
                }
                // Resolve second operand to address or value (overwrites addrVal if present)
                if (!op2.equals("-")) {
                    if (op2.startsWith("S,")) {
                        int idx = Integer.parseInt(op2.substring(2));
                        addrVal = symtab.getAddressByIndex(idx);
                    } else if (op2.startsWith("L,")) {
                        int idx = Integer.parseInt(op2.substring(2));
                        addrVal = littab.literals.get(idx).address;
                    } else if (op2.startsWith("C,")) {
                        addrVal = Integer.parseInt(op2.substring(2));
                    } else {
                        // numeric register code for second operand; treat as value directly
                        try {
                            addrVal = Integer.parseInt(op2);
                        } catch (NumberFormatException ex) {
                            addrVal = 0;
                        }
                    }
                }
                machineLines.add(String.format("%-25s %-3d %-7d %-7d %-7d", asmLine, loc, opcodeNum, regNum, addrVal));
            } else if (cls.equals("DL")) {
                // Declarative statement: define constant
                int value = 0;
                if (opcodeStr.equals("1")) {
                    // DC
                    if (op1.startsWith("C,")) {
                        value = Integer.parseInt(op1.substring(2));
                    } else {
                        try {
                            value = Integer.parseInt(op1);
                        } catch (NumberFormatException ex) {
                            value = 0;
                        }
                    }
                }
                machineLines.add(String.format("%-25s %-3d %-7s %-7s %-7d", asmLine, loc, "0", "0", value));
            } else {
                // Other classes (AD) do not produce machine code
            }
        }
        // Write machine code file with header
        try (PrintWriter pw = new PrintWriter(new FileWriter(machineCodeFile))) {
            pw.println(String.format("%-25s %-3s %-7s %-7s %-7s", "Input", "LC", "Opcode", "Reg", "Addr/Val"));
            for (String s : machineLines) {
                pw.println(s);
            }
        }

        System.out.println("Assembly complete. Check intermediate.txt and machinecode.txt.");
    }
}