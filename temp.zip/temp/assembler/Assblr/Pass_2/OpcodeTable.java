import java.util.*;

/**
 * Simple opcode and register table for the assembler.  The table
 * defines a set of imperative statement mnemonics mapped to
 * numeric opcodes and a set of register names mapped to their
 * corresponding codes.  Additional instructions or registers can
 * easily be added to extend the assembler's capabilities.
 */
public class OpcodeTable {
    private static final Map<String, Integer> opcodeMap = new HashMap<>();
    private static final Map<String, Integer> regMap = new HashMap<>();
    static {
        // Imperative statements (IS)
        opcodeMap.put("STOP", 0);
        opcodeMap.put("ADD", 1);
        opcodeMap.put("SUB", 2);
        opcodeMap.put("MULT", 3);
        opcodeMap.put("MOVER", 4);
        opcodeMap.put("MOVEM", 5);
        opcodeMap.put("COMP", 6);
        opcodeMap.put("BC", 7);
        opcodeMap.put("DIV", 8);
        opcodeMap.put("READ", 9);
        opcodeMap.put("PRINT", 10);
        // Registers
        regMap.put("AREG", 1);
        regMap.put("BREG", 2);
        regMap.put("CREG", 3);
        regMap.put("DREG", 4);
    }
    /** Returns true if the given mnemonic is a recognised opcode. */
    public boolean isOpcode(String s) {
        return opcodeMap.containsKey(s);
    }
    /** Returns the numeric opcode for the given mnemonic or 0 if unknown. */
    public int getOpcode(String s) {
        return opcodeMap.getOrDefault(s, 0);
    }
    /** Returns the register code for the given register name or 0 if unknown. */
    public int getRegister(String s) {
        return regMap.getOrDefault(s, 0);
    }
}