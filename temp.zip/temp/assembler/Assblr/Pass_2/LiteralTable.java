import java.util.*;

/**
 * Simple literal table implementation.  Literals are stored in the
 * order encountered and assigned addresses when the END (or LTORG)
 * directive is processed.  Only numeric literals of the form
 * {@code =<number>} are supported.  The table records the full
 * literal string (including the '=') along with the allocated
 * address.
 */
public class LiteralTable {
    /** Represents an entry in the literal table. */
    public static class LiteralEntry {
        public final String value;
        public int address;
        public LiteralEntry(String value) {
            this.value = value;
            this.address = -1;
        }
    }

    public final List<LiteralEntry> literals = new ArrayList<>();

    /** Adds a literal to the table if it is not already present. */
    public void addLiteral(String value) {
        for (LiteralEntry l : literals) {
            if (l.value.equals(value)) {
                return;
            }
        }
        literals.add(new LiteralEntry(value));
    }

    /** Returns the index of the given literal or -1 if not found. */
    public int getLiteralIndex(String value) {
        for (int i = 0; i < literals.size(); i++) {
            if (literals.get(i).value.equals(value)) {
                return i;
            }
        }
        return -1;
    }

    /** Assigns sequential addresses starting at startAddr to all
     * literals that do not yet have an address. */
    public void assignAddresses(int startAddr) {
        int addr = startAddr;
        for (LiteralEntry l : literals) {
            if (l.address == -1) {
                l.address = addr++;
            }
        }
    }
}