// macro_pass1_with_ala.cpp

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <map>

using namespace std;

// Structure for MNT entries
struct MntEntry {
    string name;
    int mdt_index;
};

// Structure for ALA (Argument List Array)
struct AlaEntry {
    string arg_name;
    int position;
};

int main() {
    vector<MntEntry> MNT;
    vector<string> MDT;
    vector<vector<AlaEntry>> ALA_Table; // ALA per macro

    ifstream inputFile("input_macro.txt");
    ofstream mntFile("mnt.txt");
    ofstream mdtFile("mdt.txt");
    ofstream intermediateFile("intermediate.txt");
    ofstream alaFile("ala.txt");

    if (!inputFile.is_open()) {
        cout << "Error opening input file." << endl;
        return 1;
    }

    string line;
    bool is_defining_macro = false;
    map<string, int> arg_list;
    vector<AlaEntry> current_ALA;

    while (getline(inputFile, line)) {
        stringstream ss(line);
        string word;
        vector<string> tokens;
        while (ss >> word) {
            tokens.push_back(word);
        }

        if (tokens.empty()) continue;

        // Start of macro definition
        if (tokens.size() > 1 && tokens[1] == "MACRO") {
            is_defining_macro = true;

            // MNT entry
            MntEntry mnt_entry;
            mnt_entry.name = tokens[0];
            mnt_entry.mdt_index = MDT.size();
            MNT.push_back(mnt_entry);

            // Reset argument list
            arg_list.clear();
            current_ALA.clear();

            // Process macro arguments
            for (size_t i = 2; i < tokens.size(); ++i) {
                if (tokens[i].back() == ',')
                    tokens[i].pop_back();

                arg_list[tokens[i]] = i - 2; // &ARG1 → 0
                current_ALA.push_back({tokens[i], static_cast<int>(i - 2)});
            }

            ALA_Table.push_back(current_ALA);

            continue;
        }

        // End of macro definition
        if (tokens[0] == "MEND") {
            is_defining_macro = false;
            MDT.push_back("MEND");
            continue;
        }

        // Inside macro definition
        if (is_defining_macro) {
            string mdt_line = tokens[0];
            for (size_t i = 1; i < tokens.size(); ++i) {
                string operand = tokens[i];
                if (operand.back() == ',')
                    operand.pop_back();

                // Replace argument with positional symbol
                if (arg_list.count(operand)) {
                    mdt_line += " #" + to_string(arg_list[operand]);
                } else {
                    mdt_line += " " + operand;
                }

                if (i < tokens.size() - 1)
                    mdt_line += ",";
            }
            MDT.push_back(mdt_line);
        } else {
            // Non-macro line → intermediate file
            intermediateFile << line << endl;
        }
    }

    // Write MNT
    for (const auto& entry : MNT) {
        mntFile << entry.name << " " << entry.mdt_index << endl;
    }

    // Write MDT
    for (const auto& def_line : MDT) {
        mdtFile << def_line << endl;
    }

    // Write ALA
    for (size_t i = 0; i < ALA_Table.size(); ++i) {
        alaFile << "ALA for Macro: " << MNT[i].name << endl;
        for (const auto& entry : ALA_Table[i]) {
            alaFile << entry.position << " -> " << entry.arg_name << endl;
        }
        alaFile << "----------------------" << endl;
    }

    cout << "Pass 1 of Macro Processor completed.\n";
    cout << "Generated: mnt.txt, mdt.txt, ala.txt, and intermediate.txt\n";

    return 0;
}
